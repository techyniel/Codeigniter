<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');



$lang['breadcrumd_go_to']      = 'Punta sa';
$lang['breadcrumd_refresh_to'] = 'I-refresh ang';
