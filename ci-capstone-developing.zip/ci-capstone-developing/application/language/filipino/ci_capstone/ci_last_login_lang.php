<?php

defined('BASEPATH') or exit('Direct Script is not allowed');

$lang['last_login_label'] = 'Huling Nag-Login';
