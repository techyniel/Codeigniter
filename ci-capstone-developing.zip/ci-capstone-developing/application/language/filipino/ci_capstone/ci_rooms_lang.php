<?php
/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');
/**
 * Author: Jink Po
 *         pojinkee1@gmail.com
 *         @shikai06
 */
//Create Rooms Form
$lang['create_room_heading']                   = 'Lumikha ng Kwarto';
$lang['create_room_number_label']              = 'Numero ng Kwarto:';
$lang['create_room_description_label']         = 'Deskripsyon:';
$lang['create_room_succesfully_added_message'] = 'Matagumpay na Naidagdag ang Kwarto!!';
$lang['create_room_submit_button_label']       = 'Lumikha Kwarto';

//Room Table Header
$lang['index_room_heading']        = 'Kwarto';
$lang['index_room_number_th']      = 'Numero ng Kwarto';
$lang['index_room_description_th'] = 'Deskripsyon';




