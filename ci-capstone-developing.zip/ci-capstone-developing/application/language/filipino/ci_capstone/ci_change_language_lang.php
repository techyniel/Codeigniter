<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');



$lang['change_lang_label']       = 'Palitan ang Lingwahe';
$lang['change_lang_combo_label'] = 'Pumili ang Lingwahe';
$lang['change_lang_btn_label']   = 'I-save ang Lingwahe';
$lang['lang_label']              = 'Wika';
