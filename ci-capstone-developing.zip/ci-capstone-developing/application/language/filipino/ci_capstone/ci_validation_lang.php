<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['validation_numeric_0_to_9'] = 'Maaaring Pumili ng Score sa {field}.';
$lang['validation_human_name']     = 'Hindi Wasto ang Format {field}.';
$lang['validation_school_id']      = 'Hindi Wasto ang Format sa {field}. Maaaring lamang XXXX-XXXX';
$lang['validation_password_level'] = 'MAhina {field}';
$lang['validation_username']       = 'Hindi Wasto ang {field}.';
$lang['validation_no_space']       = 'Bawal ang ispasyo {field}.';
