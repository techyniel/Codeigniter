<?php
/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');
/**
 * Author: Jinkee Po
 *         pojinkee1@gmail.com
 *         @shikai06
 */
//Subject Form
$lang['create_education_heading']                   = 'Lumikha ng Edukasyon';
$lang['create_education_code_label']                = 'Edukasyon Code:';
$lang['create_education_description_label']         = 'Deskripsyon:';
$lang['create_education_submit_button_label']       = 'Lumikha ng Edukasyon';
$lang['create_education_succesfully_added_message'] = 'Matagumpay na Naidagdag ang Edukasyon!!';

//Subject Table header
$lang['index_education_heading']        = 'Edukasyon';
$lang['index_education_code_th']        = 'Edukasyon';
$lang['index_education_description_th'] = 'Deskripsyon';




