<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');
/**
 * Author: Jinkee Po
 *         pojinkee1@gmail.com
 *         @shikai06
 */
//Asignatura Offer Form
$lang['create_subject_offer_heading']                   = 'Lumikha Asignatura Offers';
$lang['create_subject_offer_start_label']               = 'Asignatura Offer Start:';
$lang['create_subject_offer_end_label']                 = 'Asignatura Offer End:';
$lang['create_user_id_label']                           = 'Instructor:';
$lang['create_subject_id_label']                        = 'Asignatura:';
$lang['create_room_id_label']                           = 'Kwarto:';
$lang['create_subject_offer_submit_button_label']       = 'Lumikha Asignatura Offers';
$lang['create_subject_offer_succesfully_added_message'] = 'Matagumpay na Naidagdag ang Asignatura!!';

//Asignatura Offer Table header
$lang['index_subject_offer_heading']  = 'Asignatura Offers';
$lang['index_subject_offer_start_th'] = 'Asignatura Offers Start';
$lang['index_subject_offer_end_th']   = 'Asignatura Offers End';
$lang['index_subject_offer_days_th']  = 'Araw';
$lang['index_user_id_th']             = 'Instructor';
$lang['index_subject_id_th']          = 'Asignatura';
$lang['index_room_id_th']             = 'Kwarto';




