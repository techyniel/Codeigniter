<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');
/**
 * Author: Jink Po
 *         pojinkee1@gmail.com
 *         @shikai06
 */
//Asignatura Form
$lang['create_subject_heading']                   = 'Lumikha Asignatura';
$lang['create_subject_code_label']                = 'Asignatura Code:';
$lang['create_subject_description_label']         = 'Deskripsyon:';
$lang['create_subject_unit_label']                = 'Asignatura Unit:';
$lang['create_subject_course_name_label']         = 'Ngalan sa Kurso:';
$lang['create_subject_submit_button_label']       = 'Lumikha Asignatura';
$lang['create_subject_succesfully_added_message'] = 'Matagumpay na Naidagdag ang Asignatura!!';

//Asignatura Table header
$lang['index_subject_heading_th']     = 'Asignatura';
$lang['index_subject_code_th']        = 'Asignatura';
$lang['index_subject_description_th'] = 'Deskripsyon';
$lang['index_subject_unit_th']        = 'Unit';
$lang['index_subject_course_name_th'] = 'Kurso';




