<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');

//Create Course
$lang['create_course_heading']                   = 'Lumikha ng Kurso';
$lang['create_course_code_label']                = 'Ngalan sa Kurso:';
$lang['create_course_description_label']         = 'Deskripsyon:';
$lang['create_course_code_id_label']             = 'Code School ID:';
$lang['create_course_education_label']           = 'Edukasyon:';
$lang['create_course_submit_button_label']       = 'Lumikha ng Kurs';
$lang['create_course_succesfully_added_message'] = 'Matagumpay na Naidagdag ang Kurso!!';

//Course table header
$lang['index_course_heading']      = 'Kurso';
$lang['index_course_code_th']      = 'Ngalan sa Kurso';
$lang['index_course_code_id_th']   = 'Code School ID';
$lang['index_course_desc_th']      = 'Deskripsyon';
$lang['index_course_education_th'] = 'Edukasyon';




