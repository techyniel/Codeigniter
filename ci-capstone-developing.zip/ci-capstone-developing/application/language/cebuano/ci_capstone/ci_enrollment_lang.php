<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');

$lang['enrol_student_fail_message'] = 'Fail to enroll Student.';
$lang['add_student_fail_message'] = 'Fail to add student.';
