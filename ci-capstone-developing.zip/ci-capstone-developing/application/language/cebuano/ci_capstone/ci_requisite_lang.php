<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['requisite_label']         = 'Requisite';
$lang['requisite_success_added'] = 'Requisite Successfully Added!!';
$lang['requisite_subject_label'] = 'Subject Requisite ';
$lang['create_requisite_label']  = 'Create Requisite';

//type label
$lang['requisite_type_label']     = 'Requisite Type';
$lang['requisite_co_type_label']  = 'Co-Requisite';
$lang['requisite_pre_type_label'] = 'Pre-Requisite';
