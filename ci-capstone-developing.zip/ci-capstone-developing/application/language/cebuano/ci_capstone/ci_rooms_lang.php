<?php
/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');
/**
 * Author: Jink Po
 *         pojinkee1@gmail.com
 *         @shikai06
 */
//Create Rooms Form
$lang['create_room_heading']                   = 'Add Room';
$lang['create_room_number_label']              = 'Room Number:';
$lang['create_room_description_label']         = 'Description:';
$lang['create_room_succesfully_added_message'] = 'Room Succesfully Added!!';
$lang['create_room_submit_button_label']       = 'Add Room';

//Room Table Header
$lang['index_room_heading']        = 'Rooms';
$lang['index_room_number_th']      = 'Room Number';
$lang['index_room_description_th'] = 'Description';




