<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');

$lang['user_last_login_capstion_table'] = 'Users Last Logins';

$lang['users_header']      = 'Users';
$lang['ip_address_header'] = 'Ip Address';
$lang['time_header']       = 'Time';
$lang['agent_header']      = 'Agent';
$lang['platform_header']   = 'Platform';
