<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['unit_unit_label'] = 'Unit';
$lang['unit_lec_label']  = 'Lec';
$lang['unit_lab_label']  = 'Lab';


