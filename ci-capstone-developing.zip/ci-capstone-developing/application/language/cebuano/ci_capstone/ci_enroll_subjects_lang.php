<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');

$lang['no_unit'] = 'No unit found or there is no term/year in curriclum in current term.';
$lang['unit_exceed'] = 'Total number of units exceed for this level.';
