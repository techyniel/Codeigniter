<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');

$lang['dean_course_lebal']                   = 'Dean Program';