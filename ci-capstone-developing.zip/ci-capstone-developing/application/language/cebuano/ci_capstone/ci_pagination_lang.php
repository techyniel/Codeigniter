<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['ci_pagination_next_link']  = 'Next';
$lang['ci_pagination_prev_link']  = 'Previous';
$lang['ci_pagination_first_link'] = 'First';
$lang['ci_pagination_last_link']  = 'Last';
