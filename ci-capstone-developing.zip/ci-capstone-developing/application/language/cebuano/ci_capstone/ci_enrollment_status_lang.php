<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');

$lang['enrollment_status_label']         = 'Enrollment Status';
$lang['enable_enrollment_status_label']  = 'Enable Enrollment';
$lang['disable_enrollment_status_label'] = 'Disable Enrollment';
