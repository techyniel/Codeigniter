<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['print_label'] = 'Generate Student Copy';
