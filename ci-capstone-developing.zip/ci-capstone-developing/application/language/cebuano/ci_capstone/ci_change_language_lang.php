<?php
/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');



$lang['change_lang_label'] = 'Change Language';
$lang['change_lang_combo_label'] = 'Choose Language';
$lang['change_lang_btn_label'] = 'Save Language';
$lang['lang_label'] = 'Language';
