<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['semester_first_label']  = '1st Semester';
$lang['semester_second_label'] = '2nd Semester';
$lang['semester_summer_label'] = 'Summer Semester';

$lang['semester_first_short_label']  = '1st';
$lang['semester_second_short_label'] = '2nd';
$lang['semester_summer_short_label'] = 'Summer';
