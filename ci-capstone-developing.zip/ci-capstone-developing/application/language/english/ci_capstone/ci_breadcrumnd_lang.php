<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');



$lang['breadcrumd_go_to']      = 'Go To';
$lang['breadcrumd_refresh_to'] = 'Refresh To';
