<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');
/**
 * Author: Jinkee Po
 *         pojinkee1@gmail.com
 *         @shikai06
 */
//Subject Form
$lang['create_education_heading']                   = 'Add Level';
$lang['create_education_code_label']                = 'Level Code:';
$lang['create_education_description_label']         = 'Description:';
$lang['create_education_submit_button_label']       = 'Add Level';
$lang['create_education_succesfully_added_message'] = 'Level Succesfully Added!!';

//Subject Table header
$lang['index_education_heading']        = 'Levels';
$lang['index_education_code_th']        = 'Level';
$lang['index_education_description_th'] = 'Description';
$lang['view_education_label']           = 'View Level';




