<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');



$lang['home_label'] = 'Home';

$lang['gender_female_label'] = 'Female';
$lang['gender_male_label']   = 'Male';

$lang['administrators_label']                   = 'Administrator';
$lang['access_denied_of_current_user_group']    = 'Access denied for the current user group';
$lang['another_logged_in_user_in_this_account'] = 'A User has already logged in with this account.';
