<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['db_back_up']     = 'Backup and Download Database';
$lang['database_label'] = 'Database';
