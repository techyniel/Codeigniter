<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');
/**
 * Author: Jink Po
 *         pojinkee1@gmail.com
 *         @shikai06
 */
//Create Rooms Form
$lang['create_room_heading']                   = 'Add Room';
$lang['create_room_number_label']              = 'Number:';
$lang['create_room_capacity_label']            = 'Capacity:';
$lang['create_room_description_label']         = 'Description:';
$lang['create_room_succesfully_added_message'] = 'Room Succesfully Added!!';
$lang['create_room_submit_button_label']       = 'Add Room';

//Room Table Header
$lang['index_room_heading']        = 'Rooms';
$lang['index_room_number_th']      = 'Number';
$lang['index_room_capacity_th']    = 'Capacity';
$lang['index_room_description_th'] = 'Description';


$lang['view_room_label'] = 'View Rooms';


$lang['edit_editroom_label'] = 'Edit Room';
$lang['edit_room_label']     = 'Edit';

$lang['room_succesfully_update_message'] = 'Room Succesfully Updated!!';





