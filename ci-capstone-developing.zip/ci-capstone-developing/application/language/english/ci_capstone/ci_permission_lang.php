<?php

/**
 * ENGLISH
 */
defined('BASEPATH') or exit('Direct Script is not allowed');


$lang['permission_label']                                 = 'Permissions';
$lang['only_admin_user_group_allowed_current_controller'] = 'Only "admin" user_group is allowed in the current controller.';
$lang['permission_change_success']                                 = 'Permission Successfully Updated!';
