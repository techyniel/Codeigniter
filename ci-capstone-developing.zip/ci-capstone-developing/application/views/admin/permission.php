<?php

defined('BASEPATH') OR exit('No direct script allowed');

if (isset($permission_form))
{
        echo $permission_form;
}
if (isset($table_permissions))
{
        echo $table_permissions;
}
?>
                
