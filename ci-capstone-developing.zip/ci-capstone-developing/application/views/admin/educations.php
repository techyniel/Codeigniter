<?php

defined('BASEPATH') OR exit('No direct script allowed');
if (isset($table_educations))
{
        echo $table_educations;
}
