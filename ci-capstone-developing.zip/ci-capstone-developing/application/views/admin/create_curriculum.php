<?php

defined('BASEPATH') or exit('Direct Script is not allowed');
echo $curriculum_form;
