<?php defined('BASEPATH') OR exit('No direct script allowed'); ?>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="span12"> 
            <?php echo anchor(site_url($href), ' ' . $button_label, $extra); ?> 
        </div>
    </div>
</div>