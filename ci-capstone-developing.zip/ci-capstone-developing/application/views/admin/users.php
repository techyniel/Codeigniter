<?php

defined('BASEPATH') OR exit('No direct script allowed');


if (isset($create_user_button))
{
        echo $create_user_button;
}
if (isset($export_user_button))
{
        echo $export_user_button;
}

if (isset($table_users))
{
        echo $table_users;
}
