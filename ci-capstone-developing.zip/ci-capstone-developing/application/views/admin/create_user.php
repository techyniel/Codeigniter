<?php

defined('BASEPATH') or exit('Direct Script is not allowed');
echo $user_form;
