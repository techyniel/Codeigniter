<?php

defined('BASEPATH') OR exit('No direct script allowed');
echo $table_data_last_logins;

                
