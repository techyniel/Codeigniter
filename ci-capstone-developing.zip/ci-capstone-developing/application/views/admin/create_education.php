<?php

defined('BASEPATH') or exit('Direct Script is not allowed');
echo $education_form;
