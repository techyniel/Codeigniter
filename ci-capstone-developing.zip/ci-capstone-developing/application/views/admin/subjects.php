<?php

defined('BASEPATH') OR exit('No direct script allowed');
if (isset($create_subject_button))
{
        echo $create_subject_button;
}
if (isset($table_subjects))
{
        echo $table_subjects;
}
