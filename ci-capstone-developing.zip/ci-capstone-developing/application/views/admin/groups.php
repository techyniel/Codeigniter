<?php

defined('BASEPATH') OR exit('No direct script allowed');

if (isset($table_groups))
{
        echo $table_groups;
}
        
