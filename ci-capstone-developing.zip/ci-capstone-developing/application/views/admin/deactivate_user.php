<?php

defined('BASEPATH') or exit('Direct Script is not allowed');
echo $deactivate_form;
