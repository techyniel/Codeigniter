<?php

defined('BASEPATH') OR exit('No direct script allowed');
if (isset($table_courses))
{
        echo $table_courses;
}
