<?php

defined('BASEPATH') OR exit('No direct script allowed');



if (isset($active_user_count))
{
        echo $active_user_count;
}

if (isset($dashboard_ctrl_var))
{
        echo $dashboard_ctrl_var;
}

if (isset($stud_course_count))
{
        echo $stud_course_count;
}