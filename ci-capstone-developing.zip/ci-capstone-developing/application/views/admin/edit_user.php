<?php
defined('BASEPATH') or exit('Direct Script is not allowed');
 echo $edit_user_form;