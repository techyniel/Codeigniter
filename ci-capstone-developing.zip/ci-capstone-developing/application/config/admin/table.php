<?php

defined('BASEPATH') OR exit('No direct script allowed');


$config['table_open_pagination'] = '<table class="table table-bordered data-table">';
$config['table_open_bordered']   = '<table class="table table-bordered table-striped">';
$config['table_open_invoice']    = '<table class="table table-bordered table-invoice-full">';
