<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['user_group_admin']      = 'admin';
$config['user_group_faculty']    = 'faculty';
$config['user_group_registrar']  = 'registrar';
$config['user_group_dean']       = 'dean';
$config['user_group_accounting'] = 'accounting';
$config['user_group_sso']        = 'sso';
